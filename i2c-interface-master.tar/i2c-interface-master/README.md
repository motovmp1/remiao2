_# Port Disable Script

This program is used to force disable the power on USB ports on the APEX. It functions as follows:
- Enables power on all ports at the start
- Disables power on Port 1 and waits 30 seconds
- Enables power on Port 1 and waits 60 seconds
- Disables power on Port 2 and waits 30 seconds
- Enables power on Port 2 and waits 60 seconds
- etc
- Repeats indefinitely until de user stops the program

To execute the program, run the following command:

```make clean; make all; clear; ./executable on 2 3 4 6``` will turn them on again
```make clean; make all; clear; ./executable off 2 3 4 6``` will NOT turn them on again


To stop the program, press CTRL+C_