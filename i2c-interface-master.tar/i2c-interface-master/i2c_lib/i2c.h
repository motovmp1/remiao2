/* USER CODE BEGIN Header */


/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _I2C_H_
#define _I2C_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/


/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stddef.h>

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
int I2C_Write(char* i2c_bus, uint8_t address_7bit, uint8_t* data, size_t length);
int I2C_Read(char* i2c_bus, uint8_t address_7bit, uint8_t* data, size_t length);

int I2C1_Write(uint8_t address_7bit, uint8_t* data, size_t length);
int I2C1_Read(uint8_t address_7bit, uint8_t* data, size_t length);

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* _I2C_H_ */ 