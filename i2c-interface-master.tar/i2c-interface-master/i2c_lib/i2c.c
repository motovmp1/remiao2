#include "i2c.h"
#include "stdio.h"

#include <unistd.h>				//Needed for I2C port
#include <fcntl.h>				//Needed for I2C port
#include <sys/ioctl.h>			//Needed for I2C port
#include <linux/i2c-dev.h>		//Needed for I2C port
#include <errno.h>
#include <string.h>


static const char *I2C_BUS_1 = (char*) "/dev/i2c-1";

int I2C1_Write(uint8_t address_7bit, uint8_t* data, size_t length)
{
    return I2C_Write( (char*) I2C_BUS_1, address_7bit, data, length);
}

int I2C1_Read(uint8_t address_7bit, uint8_t* data, size_t length)
{
    return I2C_Read( (char*) I2C_BUS_1, address_7bit, data, length);
}

int I2C_Write(char* i2c_bus, uint8_t address_7bit, uint8_t* data, size_t length)
{
    int ret = -1;
    int file_i2c = 0;

    file_i2c = open(i2c_bus, O_WRONLY);

	if( file_i2c < 0)
	{
		//ERROR HANDLING: you can check errno to see what went wrong
		printf("Failed to open the i2c bus");
		ret = -1;
	}
    else
    { 
        ret = ioctl(file_i2c, I2C_SLAVE, address_7bit);

        if ( ret < 0)
        {
            ret = -2;
            printf("Failed to acquire bus access and/or talk to slave.\n");
            //ERROR HANDLING; you can check errno to see what went wrong
        }
        else
        {
            ret = write( file_i2c , data, length);

            if( ret == length ) 
            {
                ret = 0;
            }
            else
            {
                printf("Error writing file: %s\n", strerror(errno));
                ret = -3;
            }
        }

        close(file_i2c);
    }

    
	return ret;
}

int I2C_Read(char* i2c_bus, uint8_t address_7bit, uint8_t* data, size_t length)
{
    int ret = -1;
    int file_i2c = 0;

    file_i2c = open(i2c_bus, O_RDONLY);

	if( file_i2c < 0)
	{
		//ERROR HANDLING: you can check errno to see what went wrong
		printf("Failed to open the i2c bus");
		ret = -1;
	}
    else
    {
        ret = ioctl(file_i2c, I2C_SLAVE, address_7bit);   

        if ( ret < 0)
        {
            ret = -2;
            printf("Failed to acquire bus access and/or talk to slave.\n");
            //ERROR HANDLING; you can check errno to see what went wrong
        }
        else
        {
            ret = read( file_i2c , data, length);

            if( ret == length ) 
            {
                ret = 0;
            }
            else
            {
                ret = -3;
                printf("Error writing file: %s\n", strerror(errno));
            }
        }

        close(file_i2c);
    }

	return ret;
}