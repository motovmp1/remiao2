// eeprom_wrapper.h

#ifndef EEPROM_WRAPPER_H
#define EEPROM_WRAPPER_H


/* Includes ------------------------------------------------------------------*/


/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stddef.h>
/* USER CODE END Includes */


/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

int init_eeprom();
int eeprom_read(uint16_t address, uint8_t* buffer, size_t length);
int eeprom_write(uint16_t address, uint8_t* buffer, size_t length);
int eeprom_get_unique_id(uint8_t* unique_id);
int eeprom_get_board_type(uint8_t* board_type);

enum eeprom_types{ 
    EEPROM_TYPE_UNKNOWN         = 0,
    EEPROM_TYPE_AT42            = 1,

}typedef EEPROM_TYPE;

#endif /* EEPROM_WRAPPER_H */
