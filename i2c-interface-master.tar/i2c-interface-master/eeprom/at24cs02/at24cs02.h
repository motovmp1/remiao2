/* USER CODE BEGIN Header */

/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _AT42CS02_H_
#define _AT42CS02_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/


/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
/* USER CODE END Includes */

//by A2-A1-A0 pins
enum at42cs02_i2c_address_7bit{ 
    AT42CS02_I2C_ADDR_000       = 0x50,
    AT42CS02_I2C_ADDR_001       = 0x51,
    AT42CS02_I2C_ADDR_010       = 0x52,
    AT42CS02_I2C_ADDR_011       = 0x53,
    AT42CS02_I2C_ADDR_100       = 0x54,
    AT42CS02_I2C_ADDR_101       = 0x55,
    AT42CS02_I2C_ADDR_110       = 0x56,
    AT42CS02_I2C_ADDR_111       = 0x57,
    AT42CS02_I2C_ADDR_SN_BIT    = 0x08
}typedef AT42CS02_I2C_ADDR;

struct at42cs02_struct{
    AT42CS02_I2C_ADDR    i2c_address_7bit;
    int                 (*i2c_read)         (uint8_t, uint8_t*, size_t);	// I2C Read (uint8_t address_7bit, uint8_t* buffer, size_t length)
    int                 (*i2c_write)    	(uint8_t, uint8_t*, size_t);    // I2C Write (uint8_t address_7bit, uint8_t* buffer, size_t length)
    int                 (*delay_ms_ptr)      (uint32_t);					// Delay ms
}typedef AT42CS02;

#define AT42CS02_INIT { AT42CS02_I2C_ADDR_000, NULL, NULL, NULL}


/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
int AT42CS02_Init(AT42CS02* pdev);

int AT42CS02_SoftReset(AT42CS02* pdev);
int AT42CS02_Get_UniqueID(AT42CS02* pdev, uint8_t* unique_id);
int AT42CS02_Get_EEPROM_Data(AT42CS02* pdev, uint8_t start_address, uint8_t* data, uint16_t length);
int AT42CS02_Set_EEPROM_Data(AT42CS02* pdev, uint8_t start_address, uint8_t* data, uint16_t length);

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* _AT42CS02_H_ */