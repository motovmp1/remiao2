#include "eeprom_wrapper.h"
#include "at24cs02/at24cs02.h"
#include "i2c_lib/i2c.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static EEPROM_TYPE eeprom_type = EEPROM_TYPE_UNKNOWN;

static AT42CS02 eeprom = AT42CS02_INIT;
static AT42CS02* p_eeprom_at42 = &eeprom;

int EEPROM_Delay_ms(uint32_t time_ms)
{
    return usleep(time_ms*1000);
}


int determine_chip()
{
    int result = 0;

    p_eeprom_at42->i2c_address_7bit = AT42CS02_I2C_ADDR_010;
    p_eeprom_at42->delay_ms_ptr = EEPROM_Delay_ms;
    p_eeprom_at42->i2c_read = I2C1_Read;
    p_eeprom_at42->i2c_write = I2C1_Write;
    

    // Try initializing AT42 EEPROM
    result = AT42CS02_Init(p_eeprom_at42);
    if (result == 0)
        return 1;

    // Neither AT42 nor XXX EEPROM is detected
    // Handle this case or report an error as per your requirement
    printf("No compatible EEPROM detected.\n");
    return 0;
}

int init_eeprom()
{
    int result = 0;

    result = determine_chip();
    if (result == 0)
        return 0;
    else if (result == 1)
    {
      eeprom_type = EEPROM_TYPE_AT42;
        return eeprom_type;
    }

    return EEPROM_TYPE_UNKNOWN;
    
}

int eeprom_read(uint16_t address, uint8_t* buffer, size_t length)
{
    int ret = 0;

    if (eeprom_type == EEPROM_TYPE_AT42)
    {
        ret = AT42CS02_Get_EEPROM_Data(p_eeprom_at42, address, buffer, length);
    }
    else
        ret = -1;

    return ret;
}

int eeprom_write(uint16_t address, uint8_t* buffer, size_t length)
{
    int ret = 0;

    if (eeprom_type == EEPROM_TYPE_AT42)
    {
        ret = AT42CS02_Set_EEPROM_Data(p_eeprom_at42, address, buffer, length);
    }
    else
        ret = -1;

    return ret;
}

int eeprom_get_unique_id(uint8_t* unique_id)
{
    int ret = 0;

    if (eeprom_type == EEPROM_TYPE_AT42)
    {
        ret = AT42CS02_Get_UniqueID(p_eeprom_at42, unique_id);
    }
    else
        ret = -1;

    return ret;
}

int eeprom_get_board_type(uint8_t* board_type)
{
    return eeprom_type;
}


