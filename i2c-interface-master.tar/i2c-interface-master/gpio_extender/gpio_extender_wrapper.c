#include "gpio_extender_wrapper.h"
#include "PCA9554/pca9554.h"
#include "i2c_lib/i2c.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static GPIO_EXTENDER_TYPE gpio_extender_type = GPIO_EXTENDER_TYPE_TYPE_UNKNOWN;

static PCA9554 gpio_extender = PCA9554_INIT;
static PCA9554* p_extender_pca9554 = &gpio_extender;

int GPIO_EXTENDER_Delay_ms(uint32_t time_ms)
{
    return usleep(time_ms*1000);
}

int determine_gpio_expander()
{
    int result = 0;

    p_extender_pca9554->i2c_address_7bit = PCA9554_I2C_ADDR_000;
    p_extender_pca9554->delay_ms_ptr = GPIO_EXTENDER_Delay_ms;
    p_extender_pca9554->i2c_read = I2C1_Read;
    p_extender_pca9554->i2c_write = I2C1_Write;
    

    // Try initializing PCA9554
    result = PCA9554_Init(p_extender_pca9554);

    if (result == 0)
    {
        return 1;
    }

    // Neither AT42 nor XXX GPIO EXTENDER is detected
    // Handle this case or report an error asd per your requirement
    printf("No compatible EEPROM detected.\n");
    return 0;
}

int init_gpio_extender()
{
    int result = 0;

    result = determine_gpio_expander();
    if (result == 0)
        return 0;
    else if (result == 1)
    {
        gpio_extender_type = GPIO_EXTENDER_TYPE_PCA9554;
        printf("Board type: %d\n", gpio_extender_type);
        return gpio_extender_type;
    }

    return GPIO_EXTENDER_TYPE_TYPE_UNKNOWN;
    
}

int gpio_extender_get_board_type(uint8_t* board_type)
{
    return gpio_extender_type;
}

int gpio_extender_turn_off_port(uint8_t port)
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        result = prepare_write_port(port);
        if (result != 0)
            return result;
        result = PCA9554_Write_Port(p_extender_pca9554, port, 0x00);
        if (result != 0)
            return result;
        result = block_write_port(port);
        if (result != 0)
            return result;
    }
    else
        return -1;

    return 0;
}

int gpio_extender_turn_off_all_ports()
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        for(int i = 0; i < NPORTS; i++)
        {
            result = gpio_extender_turn_off_port(i);
            if (result != 0)
                return result;
        }
    }
    else
        return -1;

    return 0;
}

int gpio_extender_turn_on_port(uint8_t port)
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        result = prepare_write_port(port);
        if (result != 0)
            return result;
        result = PCA9554_Write_Port(p_extender_pca9554, port, 0xFF);
        if (result != 0)
            return result;
        result = block_write_port(port);
        if (result != 0)
            return result;
    }
    else
        return -1;

    return 0;
}

int gpio_extender_turn_on_all_ports()
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        for(int i = 0; i < NPORTS; i++)
        {
            result = gpio_extender_turn_on_port(i);
            if (result != 0)
                return result;
        }
    }
    else
        return -1;

    return 0;
}

int gpio_extender_get_port_state(uint8_t port, uint8_t* state)
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        result = PCA9554_Read_Port(p_extender_pca9554, state, port);
        if (result != 0)
            return result;
    }
    else
        return -1;

    return 0;
}

int gpio_extender_get_all_ports_state(uint8_t* state)
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        for (int i = 0; i < NPORTS; i++)
        {
            result = gpio_extender_get_port_state(i, &state[i]);
            if (result != 0)
                return result;
        }
        
    }
    else
        return -1;

    return 0;
}

int block_write_port(uint8_t port)
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        result = PCA9554_Write_Configuration_Port(p_extender_pca9554, port, TURN_OFF_REGISTER);
        if (result != 0)
            return result;
    }
    else
        return -1;

    return 0;
}

int prepare_write_port(uint8_t port)
{
    int result = 0;

    if (gpio_extender_type == GPIO_EXTENDER_TYPE_PCA9554)
    {
        result = PCA9554_Write_Configuration_Port(p_extender_pca9554, port, TURN_ON_REGISTER);
        if (result != 0)
            return result;
    }
    else
        return -1;

    return 0;
}
