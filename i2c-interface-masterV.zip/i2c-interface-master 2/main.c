#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "gpio_extender/gpio_extender_wrapper.h"

int main(int argc, char *argv[])
{

    if (argc < 3) {
        printf("Usage: %s <off|on> camera1 camera2 ... camera8\n", argv[0]);
        return 1;
    }

    int ret;

    // init chip
    ret = init_gpio_extender();

    if (ret == 1)
    {
        printf("Init was successful. Starting program\n");
    }
    bool turnon = false;
    const char *action = argv[1];
    if (strcmp(action, "off") == 0) {
        printf("Turning cameras off...\n");
    } else if (strcmp(action, "on") == 0) {
        printf("Turning cmaeras OFF... in 30 seconds turning them on again...\n");
        turnon = true;

    } else {
        printf("Invalid action: %s\n", action);
        printf("Invalid action: %s\n", action);
        return 1;
    }


    for (int i = 2; i < argc; ++i) {
        int camera = atoi(argv[i]);
        if (camera >= 0 && camera <= 8) {
            ret = gpio_extender_turn_off_port(camera);
            if (ret == 0)
            {
                printf("Port %d state: OFF\n", camera);
            }
            else
            {
                printf("Error: %d\n", ret);
            }
        } else {
            printf(" Invalid camera value: %s\n", argv[i]);
        }
    }
    printf("\n");

    if(turnon){
        sleep(30);
        for (int i = 1; i < argc; ++i) {
            int camera = atoi(argv[i]);
            if (camera >= 1 && camera <= 8) {
                ret = gpio_extender_turn_on_port(camera);
                if (ret == 0)
                {
                    printf("Port %d state: ON\n", camera);
                }
                else
                {
                    printf("Error: %d\n", ret);
                }
            } else {
                printf(" Invalid camera value: %s", argv[i]);
            }
        }
        printf("\n");
    }




}