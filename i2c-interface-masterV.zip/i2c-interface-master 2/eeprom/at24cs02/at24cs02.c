#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "at24cs02.h"


static uint8_t AT42CS02_I2C_Read_N(AT42CS02* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length);
static uint8_t AT42CS02_I2C_Write_N(AT42CS02* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length);
static uint8_t AT42CS02_Delay_ms(AT42CS02* pdev, uint32_t time_ms);

int AT42CS02_Init(AT42CS02* pdev)
{
    int ret = 0;

    ret = AT42CS02_SoftReset(pdev);

    return ret;
}

int AT42CS02_SoftReset(AT42CS02* pdev)
{
    int ret = 0;
    uint8_t dummy = 0;

    //The software Reset sequence should not take more than nine dummy clock cycle 8 data + 1 ack
    ret = AT42CS02_I2C_Read_N(pdev, pdev->i2c_address_7bit, &dummy, 1);
    ret += AT42CS02_Delay_ms(pdev, 100);

    return ret;
}

int AT42CS02_Get_UniqueID(AT42CS02* pdev, uint8_t* unique_id)
{
    int ret = 0;
    const uint8_t SN_REG = 0x80;
    uint8_t i2c_sn_addr = 0;

    i2c_sn_addr = (pdev->i2c_address_7bit) | AT42CS02_I2C_ADDR_SN_BIT;

    ret = AT42CS02_I2C_Write_N(pdev, i2c_sn_addr, (uint8_t*) &SN_REG, 1);

    if(ret == 0)
    {
        ret = AT42CS02_I2C_Read_N(pdev, i2c_sn_addr, unique_id, 16);
    }

    return ret;
}

int AT42CS02_Get_EEPROM_Data(AT42CS02* pdev, uint8_t start_address, uint8_t* data, uint16_t length)
{
    int ret = 0;

    ret = AT42CS02_I2C_Write_N(pdev, pdev->i2c_address_7bit, &start_address, 1);

    if(ret == 0)
    {
        ret = AT42CS02_I2C_Read_N(pdev, pdev->i2c_address_7bit, data, length);
    }

    return ret;
}

int AT42CS02_Set_EEPROM_Data(AT42CS02* pdev, uint8_t start_address, uint8_t* data, uint16_t length)
{    
    int ret = 0;
    uint8_t buffer[257] = {0};

    buffer[0] = start_address;

    memcpy( (void *) &(buffer[1]), (const void*) data, (size_t) length);

    ret = AT42CS02_I2C_Write_N(pdev, pdev->i2c_address_7bit, buffer, length+1);

    return ret;
}



/////////////////////////////////////////////////////////////////////////////////////////

static uint8_t AT42CS02_I2C_Read_N(AT42CS02* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length)
{
	uint8_t ret = 0;

	if (pdev != NULL)
	{
		if (pdev->i2c_read != NULL)
		{
			ret = pdev->i2c_read(i2c_address_7bit, buffer, length);
		}
		else
			ret = -2;
	}
	else
		ret = -1;

	return ret;
}

static uint8_t AT42CS02_I2C_Write_N(AT42CS02* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length)
{
	uint8_t ret = 0;

	if (pdev != NULL)
	{
		if (pdev->i2c_write != NULL)
		{
			ret = pdev->i2c_write(i2c_address_7bit, buffer, length);
		}
		else
			ret = -2;
	}
	else
		ret = -1;

	return ret;
}

static uint8_t AT42CS02_Delay_ms(AT42CS02* pdev, uint32_t time_ms)
{
	uint8_t ret = 0;

	if (pdev != NULL)
	{
		if (pdev->delay_ms_ptr != NULL)
		{
			pdev->delay_ms_ptr(time_ms);
		}
		else
			ret = -2;
	}
	else
		ret = -1;

	return ret;
}