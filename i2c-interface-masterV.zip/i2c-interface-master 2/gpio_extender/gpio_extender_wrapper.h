#ifndef GPIO_EXTENDER_WRAPPER_H
#define GPIO_EXTENDER_WRAPPER_H


/* Includes ------------------------------------------------------------------*/


/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stddef.h>
/* USER CODE END Includes */


/* USER CODE BEGIN Private defines */

#define TURN_OFF_REGISTER                   0
#define CONFIG_REGISTER_VAL                 0x00
#define POLARITY_INVERTION_REGISTER_VAL     0x00
#define TURN_ON_REGISTER                    1
#define TURN_ON_STATE                       1
#define HUB_RESET_MAX_TRYS                  3
#define NPORTS                              8 

/* USER CODE END Private defines */

int init_gpio_extender();
int eeprom_get_board_type(uint8_t* board_type);
int gpio_extender_turn_off_port(uint8_t port);
int gpio_extender_turn_off_all_ports();
int gpio_extender_turn_on_port(uint8_t port);
int gpio_extender_turn_on_all_ports();
int gpio_extender_get_port_state(uint8_t port, uint8_t* state);
int gpio_extender_get_all_ports_state(uint8_t* state);
int block_write_port(uint8_t port);
int prepare_write_port(uint8_t port);

enum gpio_extender_types{ 
    GPIO_EXTENDER_TYPE_TYPE_UNKNOWN         = 0,
    GPIO_EXTENDER_TYPE_PCA9554              = 1,

}typedef GPIO_EXTENDER_TYPE;

#endif /* EEPROM_WRAPPER_H */
