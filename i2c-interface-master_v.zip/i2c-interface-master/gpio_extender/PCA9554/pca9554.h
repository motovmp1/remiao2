/* USER CODE BEGIN Header */

/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _PCA9554_H_
#define _PCA9554_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/


/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
/* USER CODE END Includes */

//by A2-A1-A0 pins
enum pca9554_i2c_address_7bit{ 
    PCA9554_I2C_ADDR_000       = 0x38,
    PCA9554_I2C_ADDR_001       = 0x39,
    PCA9554_I2C_ADDR_010       = 0X40,
    PCA9554_I2C_ADDR_011       = 0X41,
    PCA9554_I2C_ADDR_100       = 0X42,
    PCA9554_I2C_ADDR_101       = 0X43,
    PCA9554_I2C_ADDR_110       = 0X44,
    PCA9554_I2C_ADDR_111       = 0X45,
}typedef PCA9554_I2C_ADDR;

struct PCA9554_struct{
    PCA9554_I2C_ADDR    i2c_address_7bit;
    int                 (*i2c_read)         (uint8_t, uint8_t*, size_t);	// I2C Read (uint8_t address_7bit, uint8_t* buffer, size_t length)
    int                 (*i2c_write)    	(uint8_t, uint8_t*, size_t);    // I2C Write (uint8_t address_7bit, uint8_t* buffer, size_t length)
    int                 (*delay_ms_ptr)      (uint32_t);					// Delay ms
}typedef PCA9554;

#define PCA9554_INIT { PCA9554_I2C_ADDR_000, NULL, NULL, NULL}


/* USER CODE BEGIN Private defines */

#define IN_REG      0   // Input register
#define OUT_REG     1  // Output register
#define POL_REG     2  // Polarity inversion register
#define CONF_REG    3 // Config register (0=output, 1=input)
#define OUTPUT      0
#define INPUT       1
#define NPORTS      8

/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
int PCA9554_Init(PCA9554* pdev);
int PCA9554_SoftReset(PCA9554* pdev);
int PCA9554_Get_Input_Register(PCA9554* pdev, uint8_t* data);
int PCA9554_Get_Output_Register(PCA9554* pdev, uint8_t* data);
int PCA9554_Get_Polarity_Inversion_Register(PCA9554* pdev, uint8_t* data);
int PCA9554_Get_Configuration_Register(PCA9554* pdev, uint8_t* data);
int PCA9554_Read_Port(PCA9554* pdev, uint8_t* data, uint8_t port_number);
int PCA9554_Write_Port(PCA9554* pdev, uint8_t port_number, uint8_t state);
int PCA9554_Write_Output_Register(PCA9554* pdev, uint8_t* data, uint8_t state);
int PCA9554_Write_Polarity_Invertion_Register(PCA9554* pdev, uint8_t* data, uint8_t state);
int PCA9554_Write_Configuration_Register(PCA9554* pdev, uint8_t* data, uint8_t state);
int PCA9554_Write_Configuration_Port(PCA9554* pdev, uint8_t port_number, uint8_t state);
int PCA9554_Get_Data(PCA9554* pdev, uint8_t start_address, uint8_t* data, uint16_t length);
int PCA9554_Set_Data(PCA9554* pdev, uint8_t start_address, uint8_t* data, uint16_t length);



/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* _PCA9554_H_ */