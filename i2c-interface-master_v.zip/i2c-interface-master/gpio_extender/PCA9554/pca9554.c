#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "pca9554.h"

static uint8_t PCA9554_I2C_Read_N(PCA9554* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length);
static uint8_t PCA9554_I2C_Write_N(PCA9554* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length);

int PCA9554_Init(PCA9554* pdev)
{
    return 0;
}


int PCA9554_Get_Input_Register(PCA9554* pdev, uint8_t* data)
{
    int ret = 0;

    ret = PCA9554_I2C_Write_N(pdev, pdev->i2c_address_7bit, IN_REG, 1);

    if(ret == 0)
    {
        ret = PCA9554_I2C_Read_N(pdev, pdev->i2c_address_7bit, data, 1);
    }

    return ret;
}

int PCA9554_Get_Output_Register(PCA9554* pdev, uint8_t* data)
{
    int ret = 0;
    uint8_t reg[1] = {OUT_REG};

    ret = PCA9554_I2C_Write_N(pdev, pdev->i2c_address_7bit, reg, 1);

    if(ret == 0)
    {
        ret = PCA9554_I2C_Read_N(pdev, pdev->i2c_address_7bit, data, 1);
    }

    return ret;
}

int PCA9554_Get_Polarity_Inversion_Register(PCA9554* pdev, uint8_t* data)
{
    int ret = 0;
    uint8_t reg[1] = {POL_REG};

    ret = PCA9554_I2C_Write_N(pdev, pdev->i2c_address_7bit, reg, 1);

    if(ret == 0)
    {
        ret = PCA9554_I2C_Read_N(pdev, pdev->i2c_address_7bit, data, 1);
    }

    return ret;
}

int PCA9554_Get_Configuration_Register(PCA9554* pdev, uint8_t* data)
{
    int ret = 0;

    //uint8_t reg[1] = {CONF_REG};
    uint8_t reg = 0x03;
    uint8_t * ptr = &reg;

    ret = PCA9554_I2C_Write_N(pdev, pdev->i2c_address_7bit, ptr, 1);

    if(ret == 0)
    {
        ret = PCA9554_I2C_Read_N(pdev, pdev->i2c_address_7bit, data, 1);
    }

    return ret;
}

int PCA9554_Read_Port(PCA9554* pdev, uint8_t* data, uint8_t port_number)
{
    int ret = 0;
    uint8_t buff[1] = {0};

    if (port_number < 0 || port_number > NPORTS)
        return -1;

    ret = PCA9554_Get_Input_Register(pdev, buff);
    if (ret == 0)
    {
        *data = buff[0] & (1 << port_number);
    }

    return ret;
}

int PCA9554_Write_Port(PCA9554* pdev, uint8_t port_number, uint8_t state)
{

    int ret = 0;
    int ret_out_reg = 0;
    uint8_t buff[1] = {0};

    if (port_number < 0 || port_number > NPORTS)
        return -1;

    ret_out_reg = PCA9554_Get_Output_Register(pdev, buff);
    if (ret_out_reg == 0)
    {
        if (state == 0)
        {
            buff[0] &= ~(1 << port_number);
        }
        else
        {
            buff[0] |= (1 << port_number);
        }
        ret = PCA9554_Set_Data(pdev, OUT_REG, buff, 1);
    }
    else
    {
        ret = ret_out_reg;
    }

    return ret;
}

int PCA9554_Write_Output_Register(PCA9554* pdev, uint8_t* data, uint8_t state)
{
    int ret = 0;
    uint8_t buff[1] = {0};

    if (state == 0)
    {
        buff[0] = 0x00;
    }
    else
    {
        buff[0] = 0xFF;
    }

    ret = PCA9554_Set_Data(pdev, OUT_REG, buff, 1);

    return ret;
}

int PCA9554_Write_Polarity_Invertion_Register(PCA9554* pdev, uint8_t* data, uint8_t state)
{
    int ret = 0;
    uint8_t buff[1] = {0};

    if (state == 0)
    {
        buff[0] = 0x00;
    }
    else
    {
        buff[0] = 0xFF;
    }

    ret = PCA9554_Set_Data(pdev, POL_REG, buff, 1);

    return ret;
}

int PCA9554_Write_Configuration_Register(PCA9554* pdev, uint8_t* data, uint8_t state)
{
    int ret = 0;
    uint8_t buff[1] = {0};

    if (state == 0)
    {
        buff[0] = 0x00;
    }
    else
    {
        buff[0] = 0xFF;
    }

    ret = PCA9554_Set_Data(pdev, CONF_REG, buff, 1);

    return ret;
}

int PCA9554_Write_Configuration_Port(PCA9554* pdev, uint8_t port_number, uint8_t state)
{
    int ret = 0;
    uint8_t current_value[1] = {0};
    uint8_t new_value[1] = {0};

    if (port_number < 0 || port_number > NPORTS)
        return -1;

    if (state < 0 || state > 1)
        return -2;

    ret = PCA9554_Get_Configuration_Register(pdev, current_value);

    if (ret != 0){
        return ret;
    }
    if (state == 1)
    {
        new_value[0] = current_value[0] | (1 << port_number);
    }
    else
    {
        new_value[0] = current_value[0] & ~(1 << port_number);
    }
    ret = PCA9554_Set_Data(pdev, CONF_REG, new_value, 1);
    
    if (ret != 0)
        return ret;
    else
        return 0;
    
}

int PCA9554_Get_Data(PCA9554* pdev, uint8_t start_address, uint8_t* data, uint16_t length)
{
    int ret = 0;

    ret = PCA9554_I2C_Write_N(pdev, pdev->i2c_address_7bit, &start_address, 1);

    if(ret == 0)
    {
        ret = PCA9554_I2C_Read_N(pdev, pdev->i2c_address_7bit, data, length);
    }

    return ret;
}

int PCA9554_Set_Data(PCA9554* pdev, uint8_t start_address, uint8_t* data, uint16_t length)
{    
    int ret = 0;
    uint8_t buffer[257] = {0};

    buffer[0] = start_address;

    memcpy( (void *) &(buffer[1]), (const void*) data, (size_t) length);

    ret = PCA9554_I2C_Write_N(pdev, pdev->i2c_address_7bit, buffer, length+1);

    return ret;
}



/////////////////////////////////////////////////////////////////////////////////////////

static uint8_t PCA9554_I2C_Read_N(PCA9554* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length)
{
	uint8_t ret = 0;
    //printf("\n\nPCA9554_I2C_Read_N\n");
    //printf("i2c_address_7bit = %d\n", i2c_address_7bit);
    //printf("buffer = 0x%02x\n\n", *buffer);

	if (pdev != NULL)
	{
		if (pdev->i2c_read != NULL)
		{
			ret = pdev->i2c_read(i2c_address_7bit, buffer, length);
		}
		else
			ret = -2;
	}
	else
		ret = -1;

	return ret;
}

static uint8_t PCA9554_I2C_Write_N(PCA9554* pdev, uint8_t i2c_address_7bit, uint8_t* buffer, size_t length)
{
	uint8_t ret = 0;
    //printf("\n\nPCA9554_I2C_Write_N\n");
    //printf("i2c_address_7bit = %x\n", i2c_address_7bit);
    //printf("buffer = 0x%02x\n\n", *buffer);

	if (pdev != NULL)
	{
		if (pdev->i2c_write != NULL)
		{
			ret = pdev->i2c_write(i2c_address_7bit, buffer, length);
		}
		else
			ret = -2;
	}
	else
		ret = -1;

	return ret;
}

/*
static uint8_t PCA9554_Delay_ms(PCA9554* pdev, uint32_t time_ms)
{
	uint8_t ret = 0;

	if (pdev != NULL)
	{
		if (pdev->delay_ms_ptr != NULL)
		{
			pdev->delay_ms_ptr(time_ms);
		}
		else
			ret = -2;
	}
	else
		ret = -1;

	return ret;
}
*/